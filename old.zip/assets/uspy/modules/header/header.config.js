(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('headerConfig', {
            defaultCanvasWidth: 800,
            defaultCanvasHeight: 300
        })

})();