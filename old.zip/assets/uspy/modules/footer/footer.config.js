(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('footerConfig', {
            pingTimeOut: 1000, //Время опроса сервера на состояние
        })

})();