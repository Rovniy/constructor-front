(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('loginConfig', {

        })

})();