(function () {
    'use strict';

    angular
        .module('uspy')
        .controller('indexController', indexController);

    indexController.$inject = [];

    function indexController() {
        let vm = this;

        activate();
        ///////////////////
        function activate() {

        }

    }
})();