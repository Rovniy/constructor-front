(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('canvasConfig', {
            sizeCollection: [
                {
                    width: 800,
                    height: 300,
                    title: 'Обложка группы Вконтакте'
                }
            ]
        })

})();