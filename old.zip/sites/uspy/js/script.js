(function () {
    'use strict';

    angular
        .module('uspy', [
            'ngRoute',
            'ngSanitize',
            'ngCookies',
            'ui.bootstrap',
            'AccordionModule'
        ])
        .constant('config', {
            version: '0.0.1', //Текущая версия сайта
            template: 'uspy', //Шаблон сайта
            theme: 'default', //Тема сайта
            mainUrl: window.location.protocol+ '//' + window.location.host,
            copy: 'Uspy &copy &year',
            debug: window.location.host === 'uspy.local:9360',
            apiServer: 'http://localhost:3000/api'
        })
        .config(config);

    config.$inject = ['$locationProvider'];

    function config ($locationProvider) {
        $locationProvider.html5Mode(true);
    }

})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .service('socketService', socketService);

    socketService.$inject = ['$q', 'intercomService'];

    /* @ngInject */
    /**
     * Сервис работы с сокетами
     * @param {angular.IQService} $q
     * @param {intercomService} intercomService
     * @returns {socketService}
     */
    function socketService($q, intercomService) {
        // Определение браузера
        let user = detect.parse(navigator.userAgent);
        let socket = atmosphere;
        let subSocket = null;
        let wsId = someNumber() + Date.now();
        let period_heart_bit = 1;
        let refreshIntervalId;
        let handlers = [];
        let isOpened = false;
        let transport;

        // Проверка браузера и подключение соответствующего типа соединения
        if (user.browser.family == 'Firefox') {
            transport = 'long-polling';
        } else {
            transport = 'websocket';
        }
        transport = 'websocket';

        let poisonPill = atmosphere.util.parseJSON('{"close":"poison_pill"}');

        /** @type {angular.IDeferred<void>} */
        let deferredOpen = $q.defer();
        /** @type {angular.IDeferred<void>} */
        let deferredClose;
        
        // We are now ready to cut the request
        //https://github.com/Atmosphere/atmosphere/wiki/jQuery.atmosphere.js-atmosphere.js-API
        let request = {
            url: 'http://localhost:8081',
            contentType: "application/json",
            logLevel: 'debug',
            //shared : true,
            trackMessageLength: true,
            reconnectInterval: 5000,
            connectTimeout: 10000,
            transport: transport,
            fallbackTransport: 'long-polling'
        };

        request.onOpen = function (response) {
            console.info('Socket: Сокет открылся. Тип соединения:', transport);
            isOpened = true;
            transport = response.transport;

            deferredOpen && deferredOpen.resolve();
        };

        request.onReopen = function (response) {
            isOpened = true;
            console.log('Socket: Повторное открытие сокета');
        };

        // For demonstration of how you can customize the fallbackTransport using the onTransportFailure function
        request.onTransportFailure = function (errorMsg, request, response) {
            if (errorMsg.indexOf("failed on first connection") > -1) {
                localStorage.wsOpen = false;
                socket.unsubscribe();
                return;
            }
            atmosphere.util.info(errorMsg);
            if (window.EventSource) {
                request.fallbackTransport = "sse";
            }
        };

        request.onMessage = function (response) {
            let message = response.responseBody;
            try {
                let json = angular.fromJson(message);

                if (json.message_type !== 'PING') console.log('Socket: Полученное с сервера:', json);

                intercomService.emit('incoming', json);
            }
            catch (e) {
                console.log('Socket: Не валидный JSON: ', message);
                return;
            }

            if (poisonPill.close && message && poisonPill.close == message) {
                localStorage.wsOpen = false;
                socket.unsubscribe();
            }
        };

        request.onClose = function (response) {
            console.log('Socket: Сокет закрылся');
            isOpened = false;
            deferredClose && deferredClose.resolve();
        };

        request.onError = function (response) {
            intercomService.emit('WS_CONNECTION_LOSS');
            console.log('Socket: Ошибка подключение атмосферы');
            isOpened = false;
        };

        request.onReconnect = function (request, response) {
            intercomService.emit('WS_RECONNECT');


            console.log('Socket: Переподключение атмосферы');
        };

        $(window).on('beforeunload', function (evt) {
            if (socket && subSocket) {
                localStorage.wsOpen = false;
                socket.unsubscribe();
                clearInterval(refreshIntervalId);
                intercomService.emit('pass_socket');
            }
        });

        intercomService.on('incoming', function (data) {
            processHandlers(data);
        });

        //кто-то закинул сообщение в интерком
        //если websocket удерживаем мы, то передаем
        intercomService.on('outgoing', function (data) {
            if (subSocket) {
                deferredOpen.promise.then(function () {
                    subSocket.push(window.atmosphere.util.stringifyJSON(data));
                    if (data.message_type !== 'PING') console.log('Socket: Переданное на сервер:', data);
                });
            }
        });

        //кто-то закрыл сокет
        intercomService.on('pass_socket', function () {
            if (localStorage.wsId != wsId) {
                deferredOpen = $q.defer();
                setTimeout(
                    function () {
                        webSocketInit();
                    },
                    parseInt(getRandomArbitary(1, 1000), 10)
                );
            } else {
                // socket = undefined;
            }
        });

        return {
            webSocketInit: webSocketInit,
            sendMessage: sendMessage,
            removeHandler: removeHandler,
            addHandler: addHandler,
            close: close,
            isOpened: function () { return isOpened; },
            isWebSocketSupported: isWebSocketSupported
        };

        //открытие сокета. если сокет уже кто-то открыл - курим бамбук, websocket остается NaN
        function webSocketInit() {
            // если случился креш и сокет остался открыт, проверка на ласт-апдейт;
            let forceOpen = false;
            let wsLU = localStorage.wsLU;

            if (wsLU){
                let diff = Date.now() - parseInt(wsLU);
                forceOpen = diff > period_heart_bit * 5 * 1000;
            }
            //double checked locking
            if (!localStorage.wsOpen || localStorage.wsOpen !== "true" || forceOpen) {
                //https://github.com/elad/LockableStorage/blob/master/LockableStorage.js#L139
                LockableStorage.trySyncLock("wsOpen", function () {
                    if (!localStorage.wsOpen || localStorage.wsOpen !== "true" || forceOpen) {
                        localStorage.wsOpen = true;
                        localStorage.wsId = wsId;
                        localStorage.wsLU = Date.now();

                        subSocket = socket.subscribe(request);

                        if (subSocket) {
                            request.onOpen(subSocket);
                        }

                        startHeartBitInterval();
                    }
                });
            }
        }

        //отослать сообщение через веб-сокет
        function sendMessage(data) {
            intercomService.emit('outgoing', data);
        }

        function removeHandler(f) {
            for (var i = 0; i < handlers.length; i++){
                if (handlers[i] === f){
                    handlers.splice(i, 1);
                    break;
                }
            }
        }

        //TODO: добавить фильтр по type добавить хендлеры-обработчики сообщений
        function addHandler(f) {
            handlers.push(f);
        }

        /**
         * Закрытие сокета
         * @returns {angular.IPromise<void>}
         */
        function close() {
            if (socket && subSocket) {
                deferredClose = $q.defer();
                
                localStorage.wsOpen = false;
                socket.unsubscribe();
                
                return deferredClose.promise;
            }
            
            return $q.resolve();
        }

        ////вызоа всех методов. инициализируется веб-сокетом
        function processHandlers(message) {
            handlers.forEach(function (f) {
                f(message);
            });
        }

        function someNumber() {
            return Math.random() * 1000000000 | 0;
        }

        function getRandomArbitary(min, max) {
            return Math.random() * (max - min) + min;
        }

        /**
         * Запускаем цикл heartbit
         */
        function startHeartBitInterval() {
            refreshIntervalId = setInterval(function () {
                localStorage.wsLU = Date.now();
            }, period_heart_bit * 1000);
        }

        /**
         * Проверка на поддержку WS браузером
         * @return {boolean}
         */
        function isWebSocketSupported() {
            let supports = false;
            
            try {
                supports = 'WebSocket' in window && window.WebSocket.CLOSING === 2;
            } catch (e) {}
            
            return supports;
        }
    }

})();

(function () {
    'use strict';

    angular.module('AccordionModule', [])
        .directive('ngcAccordion', function () {
            let accordions = [];

            function controller($scope, $element, $attrs) {
                $scope.selectors = {header: ".accordion-tab-header:first", body: ".accordion-tab-body:first"};
                this.name = 'AccordionCtrl';
                let accordion = {
                    index: accordions.length,
                    openedTabIndex: 0,
                    bussy: false,
                    width: 0,
                    height: 0,
                    options: {
                        speed: 200
                    },
                    tabs: [],
                    parentTab: false
                };

                accordion.getBussy = function () {
                    return accordion.bussy;
                };
                accordion.changeIndex = function (index) {
                    accordion.openedTabIndex = index;
                };
                accordion.closeAll = function () {
                    angular.forEach(accordion.tabs, function (tab) {
                        tab.element.find($scope.selectors.body).width(0);
                    });
                };
                accordion.calculateHeight = function () {
                    if ($attrs.ngcAutoheight && $attrs.ngcAutoheight.toLowerCase() === "true") {
                        accordion.height = 10;
                        $element.height(10);
                        let openedTab = {};
                        let w = accordion.calculateWidth();
                        let hh = 0;
                        angular.forEach(accordion.tabs, function (tab) {
                            if (tab.opened) openedTab = tab;
                            accordion.closeAll();
                            let body = tab.element.find($scope.selectors.body);
                            body.width(w);
                            let h = body.height();
                            body.width(0);
                            if (accordion.height - 5 < h) accordion.height = h + 5;
                        });
                        if (openedTab.element)
                            openedTab.element.find($scope.selectors.body).width(w);
                        $element.height(accordion.height);
                    }
                };

                accordion.calculateWidth = function () {
                    let ret = 0;
                    angular.forEach(accordion.tabs, function (tab) {
                        ret += tab.headerWidth;
                    });
                    return $element.width() - ret;
                };

                accordion.widthCorrector = function () {
                    let w = accordion.calculateWidth();
                    if (w > 0)
                        angular.forEach(accordion.tabs, function (tab) {
                            tab.ini(w);
                        });
                };

                accordion.setTabsHeight = function () {
                    let h = accordion.height - 30;
                    angular.forEach(accordion.tabs, function (tab) {
                        tab.setHeight(h);
                    })
                };

                accordion.findByNdx = function (ndx) {
                    angular.forEach(accordion.tabs, function (tab) {
                        if (ndx === tab.ndx) return tab;
                    });
                };
                $scope.accordion = accordion;
                $scope.accordions = accordions;
                this.$scope = $scope;
            }

            function link(scope, element, attrs, ctrl) {
                let ac = scope.accordion;
                ac.name = scope.name;
                ac.width = element.width();
                ac.height = element.height();
                element.addClass('accordioncontainer');
                accordions.push(ac);
                ac.status = {i: ac.openedTabIndex, s: ac.options.speed};
                if (scope.model) scope.model = ac;
                if (scope.mdl) {
                    if (!scope.mdl.speed) scope.mdl.speed = ac.options.speed;
                    if (!scope.mdl.index) scope.mdl.index = ac.openedTabIndex;
                    scope.mdl.bussy = ac.bussy;
                }
                ac.setTabsHeight();
                $(window).resize(function () {
                    if (ac.bussy === false) {
                        scope.$apply(function () {
                            ac.calculateHeight();
                            ac.widthCorrector();

                        });
                    }
                });
                scope.$watch('mdl.index', function (newValue, oldValue) {
                    if (newValue && ac.openedTabIndex !== newValue) {
                        ac.openedTabIndex = parseInt(newValue);
                    }
                });

                scope.$watch('mdl.speed', function (newValue, oldValue) {
                    if (newValue === '') scope.mdl.speed = ac.options.speed;
                    if (newValue && ac.openedTabIndex !== newValue) {
                        let v = parseInt(newValue);
                        if (v && v >= 0 && v != '') {
                            ac.options.speed = v;
                            if (newValue !== v) scope.mdl.speed = v;
                        } else {
                            scope.mdl.speed = ac.options.speed;
                        }
                    }
                });

                scope.$watch('accordion.bussy', function (value, oldValue) {
                    if (scope.mdl) scope.mdl.bussy = value;
                });

                scope.$watch('accordion.openedTabIndex', function (value, oldValue) {
                    if (ac.bussy) {
                        ac.openedTabIndex = oldValue;
                        return;
                    }
                    if (ac.tabs.length > 0) {
                        let w = ac.calculateWidth();
                        let toOpenTab = null;
                        let toCloseTab = null;
                        angular.forEach(ac.tabs, function (tab) {
                            if (tab.index === ac.openedTabIndex) toOpenTab = tab;
                            else {
                                if (tab.opened) {
                                    toCloseTab = tab;
                                }
                            }
                        });
                        if (toOpenTab) {
                            if (toCloseTab) {
                                toCloseTab.close();
                            }
                            toOpenTab.open(w);
                            if (scope.mdl && scope.mdl.index !== value) scope.mdl.index = value;
                        } else {
                            if (toCloseTab) {
                                ac.openedTabIndex = toCloseTab.index;
                            }
                        }
                    }
                });
                scope.accordion.openedTabIndex = 0;
            }
            return {
                controller: controller,
                restrict: 'AEC',
                scope: {
                    name: '@ngcAccordion'
                    , autoHeight: '@ngcAutoheight'
                    , mdl: '=ngcModel'
                },
                link: link
            }
        })
        .directive('ngcAccordionTab', function () {
            function link(scope, element, attrs, ctrl) {
                if (scope.templateUrl) scope.templateUrl = "accordionTabTemplate.html";
                let elemHeader = element.find(ctrl.$scope.selectors.header);
                let elemBody = element.find(ctrl.$scope.selectors.body);
                element.addClass('accordiontab');
                let widgetClass = element.attr('widget-id');
                if (widgetClass) {
                    element.find('.accordion-tab-header').addClass(widgetClass);
                }
                let t = {
                    index: $("~[ngc-accordion-tab]", element).length,
                    widget: element.attr('widget-id'),
                    name: scope.name,
                    headerWidth: 0,
                    opened: false,
                    preOpened: false,
                    element: element
                };
                scope.t = t;
                scope.a = ctrl.$scope.accordion;
                elemBody.width(0);
                t.headerWidth = element.width();

                t.open = function (width) {
                    t.bodyWidth = width;
                    scope.a.bussy = true;
                    t.preOpened = true;
                    $(elemBody).show().animate({"width": width + "px"}, parseInt(scope.a.options.speed), function () {
                        scope.onOpen();
                        scope.$apply(function () {
                            scope.a.bussy = false;
                            angular.forEach(ctrl.$scope.accordions, function (a) {
                                a.widthCorrector();
                            });
                            t.opened = true;
                        });
                    });
                };

                t.close = function () {
                    t.preOpened = false;
                    scope.a.bussy = true;
                    $(elemBody).animate({"width": "0px"}, parseInt(scope.a.options.speed), function () {
                        elemBody.hide();
                        scope.$apply(function () {
                            scope.a.bussy = false;
                            t.opened = false;
                        });
                    });
                };

                t.ini = function (width) {
                    t.bodyWidth = width;
                    if (t.index === scope.a.openedTabIndex) {
                        t.opened = true;
                        t.preOpened = true;
                    }
                    if (t.opened) elemBody.width(width);
                    else elemBody.width(0);

                };

                t.setHeight = function (height) {
                    t.height = height;
                };

                elemHeader.click(function () {
                    if (!scope.a.bussy) {
                        scope.$apply(function () {
                            scope.a.changeIndex(t.index);
                        });
                    }
                });

                scope.a.tabs.push(t);
                if (scope.a.calculateHeight) scope.a.calculateHeight();
                if (scope.a.widthCorrector) scope.a.widthCorrector();
            }
            return {
                require: '^ngcAccordion',
                scope: {name: '@ngcAccordionTab', onOpen: '&ngcAccordionTabOnOpen'},
                link: link,
                transclude: true,
                templateUrl: function (element, attrs) {
                    if (attrs.ngcTemplate) return attrs.ngcTemplate;
                    return 'accordiontemplate.html';
                }
            }
        })

})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .factory('fabricFactory', fabricFactory);

    fabricFactory.$inject = ['$timeout', '$window', 'fabricCanvas', 'fabricDirtyStatus'];

    function fabricFactory($timeout, $window, fabricCanvas, fabricDirtyStatus) {
        return function (options) {

            let fabricWindow = $window.fabric;
            let canvas;
            let JSONObject;
            let self = angular.extend({
                canvasBackgroundColor: '#ffffff',
                canvasWidth: 800,
                canvasHeight: 500,
                canvasOriginalHeight: 800,
                canvasOriginalWidth: 500,
                maxContinuousRenderLoops: 100,
                continuousRenderTimeDelay: 0,
                editable: true,
                JSONExportProperties: [],
                loading: true,
                dirty: false,
                initialized: false,
                userHasClickedCanvas: false,
                downloadMultipler: 2,
                imageDefaults: {},
                textDefaults: {},
                shapeDefaults: {},
                windowDefaults: {
                    transparentCorners: false,
                    rotatingPointOffset: 25,
                    padding: 0
                },
                canvasDefaults: {
                    selection: true
                }
            }, options);

            function capitalize(string) {
                if (typeof string !== 'string') {
                    return '';
                }

                return string.charAt(0).toUpperCase() + string.slice(1);
            }

            function getActiveStyle(styleName, object) {
                object = object || canvas.getActiveObject();

                if (typeof object !== 'object' || object === null) {
                    return '';
                }

                return (object.getSelectionStyles && object.isEditing) ? (object.getSelectionStyles()[styleName] || '') : (object[styleName] || '');
            }

            function setActiveStyle(styleName, value, object) {
                object = object || canvas.getActiveObject();

                if (object.setSelectionStyles && object.isEditing) {
                    let style = {};
                    style[styleName] = value;
                    object.setSelectionStyles(style);
                } else {
                    object[styleName] = value;
                }

                self.render();
            }

            function getActiveProp(name) {
                let object = canvas.getActiveObject();

                return typeof object === 'object' && object !== null ? object[name] : '';
            }

            function setActiveProp(name, value) {
                let object = canvas.getActiveObject();
                object.set(name, value);
                self.render();
            }

            function b64toBlob(b64Data, contentType, sliceSize) {
                contentType = contentType || '';
                sliceSize = sliceSize || 512;

                let byteCharacters = atob(b64Data);
                let byteArrays = [];

                for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                    let slice = byteCharacters.slice(offset, offset + sliceSize);

                    let byteNumbers = new Array(slice.length);
                    for (let i = 0; i < slice.length; i++) {
                        byteNumbers[i] = slice.charCodeAt(i);
                    }

                    let byteArray = new Uint8Array(byteNumbers);

                    byteArrays.push(byteArray);
                }

                let blob = new Blob(byteArrays, {type: contentType});
                return blob;
            }

            function isHex(str) {
                return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/gi.test(str);
            }

            //
            // Canvas
            // ==============================================================
            self.renderCount = 0;
            self.render = function () {
                let objects = canvas.getObjects();
                for (let i in objects) {
                    objects[i].setCoords();
                }

                canvas.calcOffset();
                canvas.renderAll();
                self.renderCount++;
                //console.log('Render cycle:', self.renderCount);
            };

            self.setCanvas = function (newCanvas) {
                canvas = newCanvas;
                canvas.selection = self.canvasDefaults.selection;
            };

            self.setTextDefaults = function (textDefaults) {
                self.textDefaults = textDefaults;
            };

            self.setJSONExportProperties = function (JSONExportProperties) {
                self.JSONExportProperties = JSONExportProperties;
            };

            self.setCanvasBackgroundColor = function (color) {
                self.canvasBackgroundColor = color;
                canvas.setBackgroundColor(color);
                self.render();
            };

            self.setCanvasWidth = function (width) {
                self.canvasWidth = width;
                canvas.setWidth(width);
                self.render();
            };

            self.setCanvasHeight = function (height) {
                self.canvasHeight = height;
                canvas.setHeight(height);
                self.render();
            };

            self.setCanvasSize = function (width, height) {
                self.stopContinuousRendering();
                let initialCanvasScale = self.canvasScale;
                self.resetZoom();

                self.canvasWidth = width;
                self.canvasOriginalWidth = width;
                canvas.originalWidth = width;
                canvas.setWidth(width);

                self.canvasHeight = height;
                self.canvasOriginalHeight = height;
                canvas.originalHeight = height;
                canvas.setHeight(height);

                self.canvasScale = initialCanvasScale;
                self.render();
                self.setZoom();
                self.render();
                self.setZoom();
            };

            self.isLoading = function () {
                return self.isLoading;
            };

            self.deactivateAll = function () {
                console.log('canvas',canvas);
                canvas.discardActiveObject();
                self.deselectActiveObject();
                self.render();
            };

            self.clearCanvas = function () {
                canvas.clear();
                canvas.setBackgroundColor('#ffffff');
                self.render();
            };

            //
            // Creating Objects
            // ==============================================================
            self.addObjectToCanvas = function (object) {
                object.originalScaleX = object.scaleX;
                object.originalScaleY = object.scaleY;
                object.originalLeft = object.left;
                object.originalTop = object.top;

                canvas.add(object);
                self.setObjectZoom(object);
                canvas.setActiveObject(object);
                object.bringToFront();
                self.center();
                self.render();
            };

            //
            // Image
            // ==============================================================
            self.addImage = function (imageURL) {
                fabric.Image.fromURL(imageURL, function (object) {
                    object.id = self.createId();

                    for (let p in self.imageOptions) {
                        object[p] = self.imageOptions[p];
                    }

                    // Add a filter that can be used to turn the image
                    // into a solid colored shape.
                    let filter = new fabric.Image.filters.Tint({
                        color: '#ffffff',
                        opacity: 0
                    });
                    object.filters.push(filter);
                    object.applyFilters(canvas.renderAll.bind(canvas));

                    self.addObjectToCanvas(object);
                }, self.imageDefaults);
            };

            //
            // Shape
            // ==============================================================
            self.addShape = function (svgURL) {
                fabric.loadSVGFromURL(svgURL, function (objects) {
                    let object = fabric.util.groupSVGElements(objects, self.shapeDefaults);
                    object.id = self.createId();

                    for (let p in self.shapeDefaults) {
                        object[p] = self.shapeDefaults[p];
                    }

                    if (object.isSameColor && object.isSameColor() || !object.paths) {
                        object.setFill('#0088cc');
                    } else if (object.paths) {
                        for (let i = 0; i < object.paths.length; i++) {
                            object.paths[i].setFill('#0088cc');
                        }
                    }

                    self.addObjectToCanvas(object);
                });
            };

            //
            // Text
            // ==============================================================
            self.addText = function (str) {
                str = str || 'New Text';
                let object = new fabricWindow.Text(str, self.textDefaults);
                object.id = self.createId();

                self.addObjectToCanvas(object);
            };

            self.getText = function () {
                return getActiveProp('text');
            };

            self.setText = function (value) {
                setActiveProp('text', value);
            };

            //
            // Font Size
            // ==============================================================
            self.getFontSize = function () {
                return getActiveStyle('fontSize');
            };

            self.setFontSize = function (value) {
                setActiveStyle('fontSize', parseInt(value, 10));
                self.render();
            };

            //
            // Text Align
            // ==============================================================
            self.getTextAlign = function () {
                return capitalize(getActiveProp('textAlign'));
            };

            self.setTextAlign = function (value) {
                setActiveProp('textAlign', value.toLowerCase());
            };

            //
            // Font Family
            // ==============================================================
            self.getFontFamily = function () {
                let fontFamily = getActiveProp('fontFamily');
                return fontFamily ? fontFamily.toLowerCase() : '';
            };

            self.setFontFamily = function (value) {
                setActiveProp('fontFamily', value.toLowerCase());
            };

            //
            // Lineheight
            // ==============================================================
            self.getLineHeight = function () {
                return getActiveStyle('lineHeight');
            };

            self.setLineHeight = function (value) {
                setActiveStyle('lineHeight', parseFloat(value, 10));
                self.render();
            };

            //
            // Bold
            // ==============================================================
            self.isBold = function () {
                return getActiveStyle('fontWeight') === 'bold';
            };

            self.toggleBold = function () {
                setActiveStyle('fontWeight',
                    getActiveStyle('fontWeight') === 'bold' ? '' : 'bold');
                self.render();
            };

            //
            // Italic
            // ==============================================================
            self.isItalic = function () {
                return getActiveStyle('fontStyle') === 'italic';
            };

            self.toggleItalic = function () {
                setActiveStyle('fontStyle',
                    getActiveStyle('fontStyle') === 'italic' ? '' : 'italic');
                self.render();
            };

            //
            // Underline
            // ==============================================================
            self.isUnderline = function () {
                return getActiveStyle('textDecoration').indexOf('underline') > -1;
            };

            self.toggleUnderline = function () {
                let value = self.isUnderline() ? getActiveStyle('textDecoration').replace('underline', '') : (getActiveStyle('textDecoration') + ' underline');

                setActiveStyle('textDecoration', value);
                self.render();
            };

            //
            // Linethrough
            // ==============================================================
            self.isLinethrough = function () {
                return getActiveStyle('textDecoration').indexOf('line-through') > -1;
            };

            self.toggleLinethrough = function () {
                let value = self.isLinethrough() ? getActiveStyle('textDecoration').replace('line-through', '') : (getActiveStyle('textDecoration') + ' line-through');

                setActiveStyle('textDecoration', value);
                self.render();
            };

            //
            // Text Align
            // ==============================================================
            self.getTextAlign = function () {
                return getActiveProp('textAlign');
            };

            self.setTextAlign = function (value) {
                setActiveProp('textAlign', value);
            };

            //
            // Opacity
            // ==============================================================
            self.getOpacity = function () {
                return getActiveStyle('opacity');
            };

            self.setOpacity = function (value) {
                setActiveStyle('opacity', value);
            };

            //
            // FlipX
            // ==============================================================
            self.getFlipX = function () {
                return getActiveProp('flipX');
            };

            self.setFlipX = function (value) {
                setActiveProp('flipX', value);
            };

            self.toggleFlipX = function () {
                let value = self.getFlipX() ? false : true;
                self.setFlipX(value);
                self.render();
            };

            //
            // Align Active Object
            // ==============================================================
            self.center = function () {
                let activeObject = canvas.getActiveObject();
                if (activeObject) {
                    activeObject.center();
                    self.updateActiveObjectOriginals();
                    self.render();
                }
            };

            self.centerH = function () {
                let activeObject = canvas.getActiveObject();
                if (activeObject) {
                    activeObject.centerH();
                    self.updateActiveObjectOriginals();
                    self.render();
                }
            };

            self.centerV = function () {
                let activeObject = canvas.getActiveObject();
                if (activeObject) {
                    activeObject.centerV();
                    self.updateActiveObjectOriginals();
                    self.render();
                }
            };

            //
            // Active Object Layer Position
            // ==============================================================
            self.sendBackwards = function () {
                let activeObject = canvas.getActiveObject();
                if (activeObject) {
                    canvas.sendBackwards(activeObject);
                    self.render();
                }
            };

            self.sendToBack = function () {
                let activeObject = canvas.getActiveObject();
                if (activeObject) {
                    canvas.sendToBack(activeObject);
                    self.render();
                }
            };

            self.bringForward = function () {
                let activeObject = canvas.getActiveObject();
                if (activeObject) {
                    canvas.bringForward(activeObject);
                    self.render();
                }
            };

            self.bringToFront = function () {
                let activeObject = canvas.getActiveObject();
                if (activeObject) {
                    canvas.bringToFront(activeObject);
                    self.render();
                }
            };

            //
            // Active Object Tint Color
            // ==============================================================
            self.isTinted = function () {
                return getActiveProp('isTinted');
            };

            self.toggleTint = function () {
                let activeObject = canvas.getActiveObject();
                activeObject.isTinted = !activeObject.isTinted;
                activeObject.filters[0].opacity = activeObject.isTinted ? 1 : 0;
                activeObject.applyFilters(canvas.renderAll.bind(canvas));
            };

            self.getTint = function () {
                let object = canvas.getActiveObject();

                if (typeof object !== 'object' || object === null) {
                    return '';
                }

                if (object.filters !== undefined) {
                    if (object.filters[0] !== undefined) {
                        return object.filters[0].color;
                    }
                }
            };

            self.setTint = function (tint) {
                if (!isHex(tint)) {
                    return;
                }

                let activeObject = canvas.getActiveObject();
                if (activeObject.filters !== undefined) {
                    if (activeObject.filters[0] !== undefined) {
                        activeObject.filters[0].color = tint;
                        activeObject.applyFilters(canvas.renderAll.bind(canvas));
                    }
                }
            };

            //
            // Active Object Fill Color
            // ==============================================================
            self.getFill = function () {
                return getActiveStyle('fill');
            };

            self.setFill = function (value) {
                let object = canvas.getActiveObject();
                if (object) {
                    if (object.type === 'text') {
                        setActiveStyle('fill', value);
                    } else {
                        self.setFillPath(object, value);
                    }
                }
            };

            self.setFillPath = function (object, value) {
                if (object.isSameColor && object.isSameColor() || !object.paths) {
                    object.setFill(value);
                } else if (object.paths) {
                    for (let i = 0; i < object.paths.length; i++) {
                        object.paths[i].setFill(value);
                    }
                }
            };

            //
            // Canvas Zoom
            // ==============================================================
            self.resetZoom = function () {
                self.canvasScale = 1;
                self.setZoom();
            };

            self.setZoom = function () {
                let objects = canvas.getObjects();
                for (let i in objects) {
                    objects[i].originalScaleX = objects[i].originalScaleX ? objects[i].originalScaleX : objects[i].scaleX;
                    objects[i].originalScaleY = objects[i].originalScaleY ? objects[i].originalScaleY : objects[i].scaleY;
                    objects[i].originalLeft = objects[i].originalLeft ? objects[i].originalLeft : objects[i].left;
                    objects[i].originalTop = objects[i].originalTop ? objects[i].originalTop : objects[i].top;
                    self.setObjectZoom(objects[i]);
                }

                self.setCanvasZoom();
                self.render();
            };

            self.setObjectZoom = function (object) {
                let scaleX = object.originalScaleX;
                let scaleY = object.originalScaleY;
                let left = object.originalLeft;
                let top = object.originalTop;

                let tempScaleX = scaleX * self.canvasScale;
                let tempScaleY = scaleY * self.canvasScale;
                let tempLeft = left * self.canvasScale;
                let tempTop = top * self.canvasScale;

                object.scaleX = tempScaleX;
                object.scaleY = tempScaleY;
                object.left = tempLeft;
                object.top = tempTop;

                object.setCoords();
            };

            self.setCanvasZoom = function () {
                let width = self.canvasOriginalWidth;
                let height = self.canvasOriginalHeight;

                let tempWidth = width * self.canvasScale;
                let tempHeight = height * self.canvasScale;

                canvas.setWidth(tempWidth);
                canvas.setHeight(tempHeight);
            };

            self.updateActiveObjectOriginals = function () {
                let object = canvas.getActiveObject();
                if (object) {
                    object.originalScaleX = object.scaleX / self.canvasScale;
                    object.originalScaleY = object.scaleY / self.canvasScale;
                    object.originalLeft = object.left / self.canvasScale;
                    object.originalTop = object.top / self.canvasScale;
                }
            };

            //
            // Active Object Lock
            // ==============================================================
            self.toggleLockActiveObject = function () {
                let activeObject = canvas.getActiveObject();
                if (activeObject) {
                    activeObject.lockMovementX = !activeObject.lockMovementX;
                    activeObject.lockMovementY = !activeObject.lockMovementY;
                    activeObject.lockScalingX = !activeObject.lockScalingX;
                    activeObject.lockScalingY = !activeObject.lockScalingY;
                    activeObject.lockUniScaling = !activeObject.lockUniScaling;
                    activeObject.lockRotation = !activeObject.lockRotation;
                    activeObject.lockObject = !activeObject.lockObject;
                    self.render();
                }
            };

            //
            // Active Object
            // ==============================================================
            self.selectActiveObject = function () {
                let activeObject = canvas.getActiveObject();
                if (!activeObject) {
                    return;
                }

                self.selectedObject = activeObject;
                self.selectedObject.text = self.getText();
                self.selectedObject.fontSize = self.getFontSize();
                self.selectedObject.lineHeight = self.getLineHeight();
                self.selectedObject.textAlign = self.getTextAlign();
                self.selectedObject.opacity = self.getOpacity();
                self.selectedObject.fontFamily = self.getFontFamily();
                self.selectedObject.fill = self.getFill();
                self.selectedObject.tint = self.getTint();
            };

            self.deselectActiveObject = function () {
                self.selectedObject = false;
            };

            self.deleteActiveObject = function () {
                let activeObject = canvas.getActiveObject();
                canvas.remove(activeObject);
                self.render();
            };

            //
            // State Managers
            // ==============================================================
            self.isLoading = function () {
                return self.loading;
            };

            self.setLoading = function (value) {
                self.loading = value;
            };

            self.setDirty = function (value) {
                fabricDirtyStatus.setDirty(value);
            };

            self.isDirty = function () {
                return fabricDirtyStatus.isDirty();
            };

            self.setInitalized = function (value) {
                self.initialized = value;
            };

            self.isInitalized = function () {
                return self.initialized;
            };

            //
            // JSON
            // ==============================================================
            self.getJSON = function () {
                let initialCanvasScale = self.canvasScale;
                self.canvasScale = 1;
                self.resetZoom();

                let json = JSON.stringify(canvas.toJSON(self.JSONExportProperties));

                self.canvasScale = initialCanvasScale;
                self.setZoom();

                return json;
            };

            self.loadJSON = function (json) {
                self.setLoading(true);
                canvas.loadFromJSON(json, function () {
                    $timeout(function () {
                        self.setLoading(false);

                        if (!self.editable) {
                            self.disableEditing();
                        }

                        self.render();
                    });
                });
            };

            //
            // Download Canvas
            // ==============================================================
            self.getCanvasData = function () {
                return canvas.toDataURL({
                    width: canvas.getWidth(),
                    height: canvas.getHeight(),
                    multiplier: self.downloadMultipler
                });
            };

            self.getCanvasBlob = function () {
                let base64Data = self.getCanvasData();
                let data = base64Data.replace('data:image/png;base64,', '');
                let blob = b64toBlob(data, 'image/png');

                return URL.createObjectURL(blob);
            };

            self.download = function (name) {
                // Stops active object outline from showing in image
                self.deactivateAll();

                let initialCanvasScale = self.canvasScale;
                self.resetZoom();

                // Click an artifical anchor to 'force' download.
                let link = document.createElement('a');
                link.download = name + '.png';
                link.href = self.getCanvasBlob();
                link.click();

                self.canvasScale = initialCanvasScale;
                self.setZoom();
            };

            //
            // Continuous Rendering
            // ==============================================================
            // Upon initialization re render the canvas
            // to account for fonts loaded from CDN's
            // or other lazy loaded items.

            // Prevent infinite rendering loop
            self.continuousRenderCounter = 0;

            self.stopContinuousRendering = function () {
                $timeout.cancel(self.continuousRenderHandle);
                self.continuousRenderCounter = self.maxContinuousRenderLoops;
            };

            self.startContinuousRendering = function () {
                self.continuousRenderCounter = 0;
                self.continuousRender();
            };

            // Prevents the "not fully rendered up upon init for a few seconds" bug.
            self.continuousRender = function () {
                if (self.userHasClickedCanvas || self.continuousRenderCounter > self.maxContinuousRenderLoops) {
                    return;
                }

                self.continuousRenderHandle = $timeout(function () {
                    self.setZoom();
                    self.render();
                    self.continuousRenderCounter++;
                    self.continuousRender();
                }, self.continuousRenderTimeDelay);
            };

            //
            // Utility
            // ==============================================================
            self.setUserHasClickedCanvas = function (value) {
                self.userHasClickedCanvas = value;
            };

            self.createId = function () {
                return Math.floor(Math.random() * 10000);
            };

            //
            // Toggle Object Selectability
            // ==============================================================
            self.disableEditing = function () {
                canvas.selection = false;
                canvas.forEachObject(function (object) {
                    object.selectable = false;
                });
            };

            self.enableEditing = function () {
                canvas.selection = true;
                canvas.forEachObject(function (object) {
                    object.selectable = true;
                });
            };


            //
            // Set Global Defaults
            // ==============================================================
            self.setCanvasDefaults = function () {
                canvas.selection = self.canvasDefaults.selection;
            };

            self.setWindowDefaults = function () {
                fabricWindow.Object.prototype.transparentCorners = self.windowDefaults.transparentCorners;
                fabricWindow.Object.prototype.rotatingPointOffset = self.windowDefaults.rotatingPointOffset;
                fabricWindow.Object.prototype.padding = self.windowDefaults.padding;
            };

            //
            // Canvas Listeners
            // ============================================================
            self.startCanvasListeners = function () {
                canvas.on('object:selected', function () {
                    self.stopContinuousRendering();
                    $timeout(function () {
                        self.selectActiveObject();
                        self.setDirty(true);
                    });
                });

                canvas.on('selection:created', function () {
                    self.stopContinuousRendering();
                });

                canvas.on('selection:cleared', function () {
                    $timeout(function () {
                        self.deselectActiveObject();
                    });
                });

                canvas.on('after:render', function () {
                    canvas.calcOffset();
                });

                canvas.on('object:modified', function () {
                    self.stopContinuousRendering();
                    $timeout(function () {
                        self.updateActiveObjectOriginals();
                        self.setDirty(true);
                    });
                });
            };

            //
            // Constructor
            // ==============================================================
            self.init = function () {
                canvas = fabricCanvas.getCanvas();
                self.canvasId = fabricCanvas.getCanvasId();
                canvas.clear();

                // For easily accessing the json
                JSONObject = angular.fromJson(self.json);
                self.loadJSON(self.json);

                JSONObject = JSONObject || {};

                self.canvasScale = 1;

                JSONObject.background = JSONObject.background || '#ffffff';
                self.setCanvasBackgroundColor(JSONObject.background);

                // Set the size of the canvas
                JSONObject.width = JSONObject.width || 300;
                self.canvasOriginalWidth = JSONObject.width;

                JSONObject.height = JSONObject.height || 300;
                self.canvasOriginalHeight = JSONObject.height;

                self.setCanvasSize(self.canvasOriginalWidth, self.canvasOriginalHeight);

                self.render();
                self.setDirty(false);
                self.setInitalized(true);

                self.setCanvasDefaults();
                self.setWindowDefaults();
                self.startCanvasListeners();
                self.startContinuousRendering();
                fabricDirtyStatus.startListening();
            };

            self.init();

            return self;

        };
    }
})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .filter('reverse', [function () {
            return function (items) {
                if (items) {
                    return items.slice().reverse();
                }
            };
        }])
})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .service('fabricDirtyStatus', fabricDirtyStatus);

    fabricDirtyStatus.$inject = ['$window'];

    function fabricDirtyStatus($window) {
        let self = {
            dirty: false
        };

        function checkSaveStatus() {
            if (self.isDirty()) {
                return "Oops! You have unsaved changes.\n\nPlease save before leaving so you don't lose any work.";
            }
        }

        self.endListening = function () {
            $window.onbeforeunload = null;
            $window.onhashchange = null;
        };

        self.startListening = function () {
            $window.onbeforeunload = checkSaveStatus;
            $window.onhashchange = checkSaveStatus;
        };

        self.isDirty = function () {
            return self.dirty;
        };

        self.setDirty = function (value) {
            self.dirty = value;
        };

        return self;
    }
})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .directive('fabric', fabric)
        .directive('parentClick', parentClick);

    fabric.$inject = ['$timeout', 'fabricCanvas'];

    function fabric($timeout, fabricCanvas) {
        return {
            scope: {
                fabric: '='
            },
            controller: function ($scope, $element) {
                fabricCanvas.setElement($element);
                fabricCanvas.createCanvas();

                // Continue rendering the canvas until the user clicks
                // to avoid the "calcOffset" bug upon load.
                $('body').on('click', 'canvas', function () {
                    if ($scope.fabric.setUserHasClickedCanvas) {
                        $scope.fabric.setUserHasClickedCanvas(true);
                    }
                });

                //
                // Watching Controller Variables
                // ============================================================
                $scope.$watch('fabric.canvasBackgroundColor', function (newVal) {
                    if ($scope.fabric.setCanvasBackgroundColor) {
                        $scope.fabric.setCanvasBackgroundColor(newVal);
                    }
                });

                $scope.$watch('fabric.selectedObject.text', function (newVal) {
                    if (typeof newVal === 'string') {
                        $scope.fabric.setText(newVal);
                        $scope.fabric.render();
                    }
                });

                $scope.$watch('fabric.selectedObject.fontSize', function (newVal) {
                    if (typeof newVal === 'string' || typeof newVal === 'number') {
                        $scope.fabric.setFontSize(newVal);
                        $scope.fabric.render();
                    }
                });

                $scope.$watch('fabric.selectedObject.lineHeight', function (newVal) {
                    if (typeof newVal === 'string' || typeof newVal === 'number') {
                        $scope.fabric.setLineHeight(newVal);
                        $scope.fabric.render();
                    }
                });

                $scope.$watch('fabric.selectedObject.textAlign', function (newVal) {
                    if (typeof newVal === 'string') {
                        $scope.fabric.setTextAlign(newVal);
                        $scope.fabric.render();
                    }
                });

                $scope.$watch('fabric.selectedObject.fontFamily', function (newVal) {
                    if (typeof newVal === 'string' && newVal) {
                        $scope.fabric.setFontFamily(newVal);
                        $scope.fabric.render();
                    }
                });

                $scope.$watch('fabric.selectedObject.opacity', function (newVal) {
                    if (typeof newVal === 'string' || typeof newVal === 'number') {
                        $scope.fabric.setOpacity(newVal);
                        $scope.fabric.render();
                    }
                });

                $scope.$watch('fabric.selectedObject.fill', function (newVal) {
                    if (typeof newVal === 'string') {
                        $scope.fabric.setFill(newVal);
                        $scope.fabric.render();
                    }
                });

                $scope.$watch('fabric.selectedObject.tint', function (newVal) {
                    if (typeof newVal === 'string') {
                        $scope.fabric.setTint(newVal);
                        $scope.fabric.render();
                    }
                });
            }
        };
    }


    parentClick.$inject = ['$timeout'];

    function parentClick($timeout) {
        return {
            scope: {
                parentClick: '&'
            },
            link: function (scope, element) {
                element.mousedown(function () {
                    $timeout(function () {
                        scope.parentClick();
                    });
                })
                    .children()
                    .mousedown(function (e) {
                        e.stopPropagation();
                    });
            }
        };

    }
})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .service('fabricConstants', fabricConstants);

    fabricConstants.$inject = [];

    function fabricConstants() {
        let objectDefaults = {
            rotatingPointOffset: 20,
            padding: 0,
            borderColor: 'EEF6FC',
            cornerColor: 'rgba(64, 159, 221, 1)',
            cornerSize: 10,
            transparentCorners: false,
            hasRotatingPoint: true,
            centerTransform: true
        };

        return {

            presetSizes: [
                {
                    name: 'Portrait (8.5 x 11)',
                    height: 1947,
                    width: 1510
                },
                {
                    name: 'Landscape (11 x 8.5)',
                    width: 1947,
                    height: 1510
                },
                {
                    name: 'Business Card (3.5 x 2)',
                    height: 368,
                    width: 630
                },
                {
                    name: 'Postcard (6 x 4)',
                    height: 718,
                    width: 1068
                },
                {
                    name: 'Content/Builder Product Thumbnail',
                    height: 400,
                    width: 760
                },
                {
                    name: 'Badge',
                    height: 400,
                    width: 400
                },
                {
                    name: 'Facebook Profile Picture',
                    height: 300,
                    width: 300
                },
                {
                    name: 'Facebook Cover Picture',
                    height: 315,
                    width: 851
                },
                {
                    name: 'Facebook Photo Post (Landscape)',
                    height: 504,
                    width: 403
                },
                {
                    name: 'Facebook Photo Post (Horizontal)',
                    height: 1008,
                    width: 806
                },
                {
                    name: 'Facebook Full-Width Photo Post',
                    height: 504,
                    width: 843
                }
            ],

            fonts: [
                {name: 'Arial'},
                {name: 'Comic Sans MS'},
                {name: 'Georgia'},
                {name: 'Impact'},
                {name: 'Lucida Console'},
                {name: 'Tahoma'},
                {name: 'Times New Roman'},
                {name: 'Trebuchet MS'},
                {name: 'Verdana'},
                {name: 'Symbol'},
                {name: 'MS Sans Serif'}
            ],

            shapeCategories: [
                {
                    name: 'Popular Shapes',
                    shapes: [
                        'arrow6',
                        'bubble4',
                        'circle1',
                        'rectangle1',
                        'star1',
                        'triangle1'
                    ]
                },
                {
                    name: 'Simple Shapes',
                    shapes: [
                        'circle1',
                        'heart1',
                        'rectangle1',
                        'triangle1',
                        'star1',
                        'star2',
                        'star3',
                        'square1'
                    ]
                },
                {
                    name: 'Arrows & Pointers',
                    shapes: [
                        'arrow1',
                        'arrow9',
                        'arrow3',
                        'arrow6',
                    ]
                },
                {
                    name: 'Bubbles & Balloons',
                    shapes: [
                        'bubble5',
                        'bubble4'
                    ]
                },
                {
                    name: 'Check Marks',
                    shapes: []
                },
                {
                    name: 'Badges',
                    shapes: [
                        'badge1',
                        'badge2',
                        'badge4',
                        'badge5',
                        'badge6'
                    ]
                }
            ],

            JSONExportProperties: [
                'height',
                'width',
                'background',
                'objects',

                'originalHeight',
                'originalWidth',
                'originalScaleX',
                'originalScaleY',
                'originalLeft',
                'originalTop',

                'lineHeight',
                'lockMovementX',
                'lockMovementY',
                'lockScalingX',
                'lockScalingY',
                'lockUniScaling',
                'lockRotation',
                'lockObject',
                'id',
                'isTinted',
                'filters'
            ],

            shapeDefaults: angular.extend({
                fill: '#0088cc'
            }, objectDefaults),

            textDefaults: angular.extend({
                originX: 'left',
                scaleX: 1,
                scaleY: 1,
                fontFamily: 'Arial',
                fontSize: 40,
                fill: '#000',
                textAlign: 'left'
            }, objectDefaults)

        };
    }

})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .service('fabricCanvas', fabricCanvas);

    fabricCanvas.$inject = ['$rootScope', '$window'];

    function fabricCanvas($rootScope, $window) {

        let self = {
            canvasId: null,
            element: null,
            canvas: null
        };

        let fabricWindow = $window.fabric;

        function createId() {
            return Math.floor(Math.random() * 10000);
        }

        self.setElement = function (element) {
            self.element = element;
            $rootScope.$broadcast('canvas:element:selected');
        };

        self.createCanvas = function () {
            self.canvasId = 'fabric-canvas-' + createId();
            self.element.attr('id', self.canvasId);
            self.canvas = new fabricWindow.Canvas(self.canvasId);
            $rootScope.$broadcast('canvas:created');

            return self.canvas;
        };

        self.getCanvas = function () {
            return self.canvas;
        };

        self.getCanvasId = function () {
            return self.canvasId;
        };

        return self;
    }

})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('canvasConfig', {
            sizeCollection: [
                {
                    width: 800,
                    height: 300,
                    title: 'Обложка группы Вконтакте'
                }
            ]
        })

})();
(function () {
    'use strict';

    let module;

    module = angular.module("laneolson.ui.dragdrop", []);

    module.directive('dragAndDrop', [
        '$document', function ($document) {
            return {
                restrict: 'AE',
                scope: {
                    onItemPlaced: "&",
                    onItemRemoved: "&",
                    onDrag: "&",
                    onDragStart: "&",
                    onDragEnd: "&",
                    onDragEnter: "&",
                    onDragLeave: "&",
                    enableSwap: "=",
                    fixedPositions: "="
                },
                require: 'dragAndDrop',
                controller: [
                    '$q', '$scope', function ($q, $scope) {
                        let currentDroppable, draggables, droppables, element, handlers, isInside, isIntersecting, isReady;
                        $scope.draggables = draggables = [];
                        $scope.droppables = droppables = [];
                        $scope.isDragging = false;
                        $scope.currentDraggable = null;
                        currentDroppable = null;
                        element = null;
                        isReady = false;
                        handlers = [];
                        isInside = function (point, bounds) {
                            let ref, ref1;
                            return (bounds.left < (ref = point[0]) && ref < bounds.right) && (bounds.top < (ref1 = point[1]) && ref1 < bounds.bottom);
                        };
                        isIntersecting = function (r1, r2) {
                            return !(r2.left > r1.right || r2.right < r1.left || r2.top > r1.bottom || r2.bottom < r1.top);
                        };
                        this.on = function (e, cb) {
                            if (e === "ready" && isReady) {
                                cb();
                            }
                            return handlers.push({
                                name: e,
                                cb: cb
                            });
                        };
                        this.trigger = function (e) {
                            let h, i, len, results;
                            if (e === "ready") {
                                isReady = true;
                            }
                            results = [];
                            for (i = 0, len = handlers.length; i < len; i++) {
                                h = handlers[i];
                                if (h.name === e) {
                                    results.push(h.cb());
                                } else {
                                    results.push(void 0);
                                }
                            }
                            return results;
                        };
                        this.isReady = function () {
                            return isReady;
                        };
                        this.setDragAndDropElement = function (el) {
                            return element = el;
                        };
                        this.getDragAndDropElement = function () {
                            return element;
                        };
                        this.checkForIntersection = function () {
                            let dropSpot, i, len, results;
                            results = [];
                            for (i = 0, len = droppables.length; i < len; i++) {
                                dropSpot = droppables[i];
                                if (isInside($scope.currentDraggable.midPoint, dropSpot)) {
                                    if (!dropSpot.isActive) {
                                        this.setCurrentDroppable(dropSpot);
                                        dropSpot.activate();
                                        results.push(this.fireCallback('drag-enter'));
                                    } else {
                                        results.push(void 0);
                                    }
                                } else {
                                    if (dropSpot.isActive) {
                                        this.setCurrentDroppable(null);
                                        dropSpot.deactivate();
                                        results.push(this.fireCallback('drag-leave'));
                                    } else {
                                        results.push(void 0);
                                    }
                                }
                            }
                            return results;
                        };
                        this.setCurrentDraggable = function (draggable) {
                            $scope.currentDraggable = draggable;
                            if (draggable) {
                                this.fireCallback('drag-start');
                            }
                            return $scope.$evalAsync(function () {
                                $scope.currentDraggable = draggable;
                                if (draggable) {
                                    return $scope.isDragging = true;
                                } else {
                                    return $scope.isDragging = false;
                                }
                            });
                        };
                        this.getCurrentDraggable = function () {
                            return $scope.currentDraggable;
                        };
                        this.setCurrentDroppable = function (droppable) {
                            return currentDroppable = droppable;
                        };
                        this.getCurrentDroppable = function () {
                            return currentDroppable;
                        };
                        this.addDroppable = function (droppable) {
                            return droppables.push(droppable);
                        };
                        this.addDraggable = function (draggable) {
                            return draggables.push(draggable);
                        };
                        this.fireCallback = function (type, e) {
                            let state;
                            state = {
                                draggable: this.getCurrentDraggable(),
                                droppable: this.getCurrentDroppable(),
                                dragEvent: e
                            };
                            switch (type) {
                                case 'drag-end':
                                    if (typeof $scope.onDragEnd === "function") {
                                        $scope.onDragEnd(state);
                                    }
                                    return this.trigger("drag-end");
                                case 'drag-start':
                                    if (typeof $scope.onDragStart === "function") {
                                        $scope.onDragStart(state);
                                    }
                                    return this.trigger("drag-start");
                                case 'drag':
                                    return typeof $scope.onDrag === "function" ? $scope.onDrag(state) : void 0;
                                case 'item-assigned':
                                    return typeof $scope.onItemPlaced === "function" ? $scope.onItemPlaced(state) : void 0;
                                case 'item-removed':
                                    return typeof $scope.onItemRemoved === "function" ? $scope.onItemRemoved(state) : void 0;
                                case 'drag-leave':
                                    return typeof $scope.onDragLeave === "function" ? $scope.onDragLeave(state) : void 0;
                                case 'drag-enter':
                                    return typeof $scope.onDragEnter === "function" ? $scope.onDragEnter(state) : void 0;
                            }
                        };
                    }
                ],
                link: function (scope, element, attrs, ngDragAndDrop) {
                    let bindEvents, moveEvents, onMove, onRelease, releaseEvents, unbindEvents;
                    moveEvents = "touchmove mousemove";
                    releaseEvents = "touchend mouseup";
                    ngDragAndDrop.setDragAndDropElement(element);
                    bindEvents = function () {
                        $document.on(moveEvents, onMove);
                        $document.on(releaseEvents, onRelease);
                        ngDragAndDrop.on("drag-start", function () {
                            return element.addClass("dragging");
                        });
                        return ngDragAndDrop.on("drag-end", function () {
                            return element.removeClass("dragging");
                        });
                    };
                    unbindEvents = function () {
                        $document.off(moveEvents, onMove);
                        return $document.off(releaseEvents, onRelease);
                    };
                    onRelease = function (e) {
                        var draggable, dropSpot;
                        draggable = ngDragAndDrop.getCurrentDraggable();
                        dropSpot = ngDragAndDrop.getCurrentDroppable();
                        if (draggable) {
                            element.addClass("drag-return");
                            setTimeout(function () {
                                return element.removeClass("drag-return");
                            }, 500);
                            ngDragAndDrop.fireCallback('drag-end', e);
                            draggable.deactivate();
                            if (dropSpot && !dropSpot.isFull) {
                                ngDragAndDrop.fireCallback('item-assigned', e);
                                draggable.assignTo(dropSpot);
                                dropSpot.itemDropped(draggable);
                            } else if (dropSpot && dropSpot.isFull && scope.enableSwap) {
                                dropSpot.items[0].returnToStartPosition();
                                dropSpot.items[0].removeFrom(dropSpot);
                                ngDragAndDrop.fireCallback('item-assigned', e);
                                draggable.assignTo(dropSpot);
                                dropSpot.itemDropped(draggable);
                                ngDragAndDrop.fireCallback('item-removed', e);
                            } else {
                                draggable.isAssigned = false;
                                if (scope.fixedPositions) {
                                    draggable.returnToStartPosition();
                                }
                            }
                            if (dropSpot) {
                                dropSpot.deactivate();
                            }
                            return ngDragAndDrop.setCurrentDraggable(null);
                        }
                    };
                    onMove = function (e) {
                        let draggable;
                        draggable = ngDragAndDrop.getCurrentDraggable();
                        if (draggable) {
                            ngDragAndDrop.fireCallback('drag', e);
                            if (e.touches && e.touches.length === 1) {
                                draggable.updateOffset(e.touches[0].clientX, e.touches[0].clientY);
                            } else {
                                draggable.updateOffset(e.clientX, e.clientY);
                            }
                            return ngDragAndDrop.checkForIntersection();
                        }
                    };
                    bindEvents();
                    return ngDragAndDrop.trigger("ready");
                }
            };
        }
    ]);

    module.directive('dragItem', [
        '$window', '$document', '$compile', function ($window, $document, $compile) {
            return {
                restrict: 'EA',
                require: '^dragAndDrop',
                scope: {
                    x: "@",
                    y: "@",
                    dropTo: "@",
                    dragId: "@",
                    dragEnabled: "=",
                    dragData: "=",
                    clone: "=",
                    lockHorizontal: "=",
                    lockVertical: "="
                },
                link: function (scope, element, attrs, ngDragAndDrop) {
                    let bindEvents, cloneEl, eventOffset, height, init, onPress, pressEvents, setClonePosition,
                        startPosition, transformEl, unbindEvents, updateDimensions, w, width;
                    cloneEl = width = height = startPosition = transformEl = eventOffset = pressEvents = w = null;
                    console.log('dragItem-OK');
                    updateDimensions = function () {
                        scope.left = scope.x + element[0].offsetLeft;
                        scope.right = scope.left + width;
                        scope.top = scope.y + element[0].offsetTop;
                        scope.bottom = scope.top + height;
                        scope.midPoint = [scope.left + width / 2, scope.top + height / 2];
                        if (scope.lockVertical) {
                            scope.percent = 100 * (scope.left + element[0].clientWidth / 2) / element.parent()[0].clientWidth;
                            return scope.percent = Math.min(100, Math.max(0, scope.percent));
                        }
                    };
                    setClonePosition = function () {
                        let elemRect, leftOffset, topOffset;
                        elemRect = element[0].getBoundingClientRect();
                        leftOffset = elemRect.left + eventOffset[0];
                        topOffset = elemRect.top + eventOffset[1];
                        return scope.updateOffset(leftOffset, topOffset);
                    };
                    scope.setPercentPostion = function (xPercent, yPercent) {
                        let newX, newY;
                        newY = (element.parent()[0].clientHeight * (yPercent / 100)) - element[0].clientHeight / 2;
                        newX = (element.parent()[0].clientWidth * (xPercent / 100)) - element[0].clientWidth / 2;
                        return scope.setPosition(newX, newY);
                    };
                    scope.setPosition = function (x, y) {
                        scope.x = scope.lockHorizontal ? 0 : x;
                        scope.y = scope.lockVertical ? 0 : y;
                        updateDimensions();
                        return transformEl.css({
                            "transform": "translate(" + scope.x + "px, " + scope.y + "px)",
                            "-webkit-transform": "translate(" + scope.x + "px, " + scope.y + "px)",
                            "-ms-transform": "translate(" + scope.x + "px, " + scope.y + "px)"
                        });
                    };
                    scope.updateOffset = function (x, y) {
                        if (scope.clone) {
                            return scope.setPosition(x - (eventOffset[0] + element[0].offsetLeft), y - (eventOffset[1] + element[0].offsetTop));
                        } else {
                            return scope.setPosition(x - (eventOffset[0] + element[0].offsetLeft), y - (eventOffset[1] + element[0].offsetTop));
                        }
                    };
                    scope.returnToStartPosition = function () {
                        return scope.setPosition(startPosition[0], startPosition[1]);
                    };
                    scope.assignTo = function (dropSpot) {
                        scope.dropSpots.push(dropSpot);
                        scope.isAssigned = true;
                        if (dropSpot.dropId) {
                            return element.addClass("in-" + dropSpot.dropId);
                        }
                    };
                    scope.removeFrom = function (dropSpot) {
                        var index;
                        index = scope.dropSpots.indexOf(dropSpot);
                        if (index > -1) {
                            if (dropSpot.dropId) {
                                element.removeClass("in-" + dropSpot.dropId);
                            }
                            scope.dropSpots.splice(index, 1);
                            if (scope.dropSpots.length < 1) {
                                scope.isAssigned = false;
                            }
                            return dropSpot.removeItem(scope);
                        }
                    };
                    scope.addClass = function (className) {
                        return element.addClass(className);
                    };
                    scope.removeClass = function (className) {
                        return element.removeClass(className);
                    };
                    scope.toggleClass = function (className) {
                        if (element.hasClass(className)) {
                            return element.removeClass(className);
                        } else {
                            return element.addClass(className);
                        }
                    };
                    scope.activate = function () {
                        element.addClass("drag-active");
                        return scope.isDragging = true;
                    };
                    scope.deactivate = function () {
                        eventOffset = [0, 0];
                        if (scope.clone) {
                            cloneEl.removeClass("clone-active");
                        }
                        element.removeClass("drag-active");
                        return scope.isDragging = false;
                    };
                    bindEvents = function () {
                        element.on(pressEvents, onPress);
                        return w.bind("resize", updateDimensions);
                    };
                    unbindEvents = function () {
                        element.off(pressEvents, onPress);
                        return w.unbind("resize", updateDimensions);
                    };
                    onPress = function (e) {
                        var dropSpot, elemRect, i, len, ref, spot;
                        if (!scope.dragEnabled) {
                            return;
                        }
                        if (e.touches && e.touches.length === 1) {
                            eventOffset = [e.touches[0].clientX - scope.left, e.touches[0].clientY - scope.top];
                        } else {
                            elemRect = element[0].getBoundingClientRect();
                            eventOffset = [e.clientX - elemRect.left, e.clientY - elemRect.top];
                        }
                        if (scope.clone) {
                            scope.returnToStartPosition();
                            cloneEl.addClass("clone-active");
                            setClonePosition();
                        }
                        ngDragAndDrop.setCurrentDraggable(scope);
                        scope.activate();
                        scope.isAssigned = false;
                        ngDragAndDrop.checkForIntersection();
                        dropSpot = ngDragAndDrop.getCurrentDroppable();
                        ref = scope.dropSpots;
                        for (i = 0, len = ref.length; i < len; i++) {
                            spot = ref[i];
                            scope.removeFrom(spot);
                            ngDragAndDrop.fireCallback('item-removed', e);
                        }
                        return e.preventDefault();
                    };
                    init = function () {
                        var testing;
                        if (scope.dragId) {
                            element.addClass(scope.dragId);
                        }
                        eventOffset = [0, 0];
                        width = element[0].offsetWidth;
                        height = element[0].offsetHeight;
                        scope.dropSpots = [];
                        scope.isAssigned = false;
                        if (scope.x == null) {
                            scope.x = 0;
                        }
                        if (scope.y == null) {
                            scope.y = 0;
                        }
                        startPosition = [scope.x, scope.y];
                        pressEvents = "touchstart mousedown";
                        w = angular.element($window);
                        updateDimensions();
                        ngDragAndDrop.addDraggable(scope);
                        bindEvents();
                        if (scope.dragData) {
                            angular.extend(scope, scope.dragData);
                        }
                        if (scope.clone) {
                            scope[scope.dragData.key] = scope.dragData.value;
                            testing = $compile(angular.element("<div>" + element.html() + "</div>"))(scope);
                            cloneEl = testing;
                            cloneEl.addClass("clone");
                            cloneEl.addClass(element.attr("class"));
                            angular.element(ngDragAndDrop.getDragAndDropElement()).append(cloneEl);
                            transformEl = cloneEl;
                        } else {
                            transformEl = element;
                        }
                        scope.returnToStartPosition();
                        scope.$emit('drag-ready', scope);
                        return scope.$on('$destroy', function () {
                            return unbindEvents();
                        });
                    };
                    return ngDragAndDrop.on("ready", init);
                }
            };
        }
    ]);

    module.directive('dropSpot', [
        '$window', function ($window) {
            return {
                restrict: 'AE',
                require: '^dragAndDrop',
                transclude: true,
                scope: {
                    dropId: "@",
                    maxItems: "=",
                    width: "@",
                    height: "@"
                },
                template: "<div class='drop-content' ng-class='{ \"drop-full\": isFull }' style='width:{{width}}px; height:{{height}}px' ng-transclude></div>",
                link: function (scope, element, attrs, ngDragAndDrop) {
                    console.log('width:',scope.width, 'height:', scope.height);
                    var addItem, bindEvents, getDroppedPosition, handleResize, unbindEvents, updateDimensions, w;
                    console.log('dropSpot-OK');
                    updateDimensions = function () {
                        scope.left = element[0].offsetLeft;
                        scope.top = element[0].offsetTop;
                        scope.right = scope.left + element[0].offsetWidth;
                        return scope.bottom = scope.top + element[0].offsetHeight;
                    };
                    getDroppedPosition = function (item) {
                        var dropSize, itemSize, xPos, yPos;
                        dropSize = [scope.right - scope.left, scope.bottom - scope.top];
                        itemSize = [item.right - item.left, item.bottom - item.top];
                        switch (item.dropTo) {
                            case "top":
                                xPos = scope.left + (dropSize[0] - itemSize[0]) / 2;
                                yPos = scope.top;
                                break;
                            case "bottom":
                                xPos = scope.left + (dropSize[0] - itemSize[0]) / 2;
                                yPos = scope.top + (dropSize[1] - itemSize[1]);
                                break;
                            case "left":
                                xPos = scope.left;
                                yPos = scope.top + (dropSize[1] - itemSize[1]) / 2;
                                break;
                            case "right":
                                xPos = scope.left + (dropSize[0] - itemSize[0]);
                                yPos = scope.top + (dropSize[1] - itemSize[1]) / 2;
                                break;
                            case "top left":
                                xPos = scope.left;
                                yPos = scope.top;
                                break;
                            case "bottom right":
                                xPos = scope.left + (dropSize[0] - itemSize[0]);
                                yPos = scope.top + (dropSize[1] - itemSize[1]);
                                break;
                            case "bottom left":
                                xPos = scope.left;
                                yPos = scope.top + (dropSize[1] - itemSize[1]);
                                break;
                            case "top right":
                                xPos = scope.left + (dropSize[0] - itemSize[0]);
                                yPos = scope.top;
                                break;
                            case "center":
                                xPos = scope.left + (dropSize[0] - itemSize[0]) / 2;
                                yPos = scope.top + (dropSize[1] - itemSize[1]) / 2;
                                break;
                            default:
                                if (item.dropOffset) {
                                    xPos = scope.left + item.dropOffset[0];
                                    yPos = scope.top + item.dropOffset[1];
                                }
                        }
                        return [xPos, yPos];
                    };
                    scope.itemDropped = function (item) {
                        var added, newPos;
                        added = addItem(item);
                        if (added) {
                            if (item.dropTo) {
                                newPos = getDroppedPosition(item);
                                return item.updateOffset(newPos[0], newPos[1]);
                            } else {
                                return item.dropOffset = [item.left - scope.left, item.top - scope.top];
                            }
                        } else {
                            if (scope.fixedPositions) {
                                return item.returnToStartPosition();
                            }
                        }
                    };
                    addItem = function (item) {
                        if (!scope.isFull) {
                            scope.items.push(item);
                            if (scope.items.length >= scope.maxItems) {
                                scope.isFull = true;
                            }
                            return item;
                        }
                        return false;
                    };
                    scope.removeItem = function (item) {
                        var index;
                        index = scope.items.indexOf(item);
                        if (index > -1) {
                            scope.items.splice(index, 1);
                            if (scope.items.length < scope.maxItems) {
                                return scope.isFull = false;
                            }
                        }
                    };
                    scope.activate = function () {
                        scope.isActive = true;
                        return element.addClass("drop-hovering");
                    };
                    scope.deactivate = function () {
                        scope.isActive = false;
                        ngDragAndDrop.setCurrentDroppable(null);
                        return element.removeClass("drop-hovering");
                    };
                    handleResize = function () {
                        var i, item, len, newPos, ref, results;
                        updateDimensions();
                        ref = scope.items;
                        results = [];
                        for (i = 0, len = ref.length; i < len; i++) {
                            item = ref[i];
                            newPos = getDroppedPosition(item);
                            results.push(item.updateOffset(newPos[0], newPos[1]));
                        }
                        return results;
                    };
                    bindEvents = function () {
                        return w.bind("resize", handleResize);
                    };
                    unbindEvents = function () {
                        return w.unbind("resize", handleResize);
                    };
                    if (scope.dropId) {
                        element.addClass(scope.dropId);
                    }
                    w = angular.element($window);
                    bindEvents();
                    scope.$on('$destroy', function () {
                        return unbindEvents();
                    });
                    updateDimensions();
                    scope.isActive = false;
                    scope.items = [];
                    return ngDragAndDrop.addDroppable(scope);
                }
            };
        }
    ]);

})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .directive('widgetSomeText', widgetSomeText);

    widgetSomeText.$inject = ['intercomService'];

    function widgetSomeText(intercomService) {
        return {
            restrict: 'EA',
            template:
            '<div ng-click="addWidget()">' +
            '<i class="fa {{widget.icon}} fa-3x ta-center"></i>' +
            '<span class="title" ng-bind="widget.title"></span>' +
            '</div>' +
            '<span class="desc" ng-click="showDescription(widget.desc)">' +
            '<i class="fa fa-question"></i>' +
            '</span>',
            link: function (scope, element, attributes) {
                scope.widget = {
                    title: 'Любой текст',
                    icon: 'fa-font',
                    desc: 'Данный виджет вставляет любой статичный текст на холст'
                };

                scope.addWidget = addWidget;
                scope.showDescription = showDescription;

                function addWidget() {
                    intercomService.emit('widget: add: text', scope.widget);
                }

                /**
                 * Открытие окна с описанием виджета
                 */
                function showDescription() {
                    intercomService.emit('widget: show-description', scope.widget);
                }
            }
        };
    }
})();

(function () {
    'use strict';

    angular
        .module('uspy')
        .run(run);

        run.$inject = ['$rootScope','$timeout','socketService'];

    function run ($rootScope,$timeout,socketService) {

        socketService.addHandler(function (m) {
            // $timeout для запуска $digest
            $timeout(function () {
                $rootScope.$broadcast(m.message_type, m);
            });
        });



    }
})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .config(config);

    config.$inject = ['$routeProvider'];
    
    function config ($routeProvider) {
        $routeProvider
            .when ('/', {
                templateUrl: '/index/_index.html',
                controller: 'indexController',
                controllerAs: 'vm'
            })
            .when ('/login', {
                templateUrl: '/login/_login.html',
                controller: 'loginController',
                controllerAs: 'vm'
            })
            .when ('/constructor/:userID', {
                templateUrl: '/constructor/_constructor.html'
            })
            .otherwise({
                redirectTo: '/'
            });
    }

})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .controller('appController', appController);

    appController.$inject = ['$rootScope','intercomService', 'userProfileService', '$location', 'config'];

    function appController($rootScope, intercomService, userProfileService, $location, config) {
        let app = this;
        app.overlay = false;

        activate();

        ////////////////

        function activate() {
            constructorActivate(); //Включение и отключение отображения оверлея

            _onLogin(); //Событие при входе пользователя
        }

        /**
         * Включение и отключение отображения оверлея
         */
        function constructorActivate() {
            intercomService.on('constructor-on', function () {
                app.overlay = true;
            });
            intercomService.on('constructor-off', function () {
                app.overlay = false;
            });
        }

        /**
         * Событие при входе пользователя
         * @returns {Promise.<TResult>}
         * @private
         */
        function _onLogin() {
            if (!config.debug) {
                userProfileService
                    .loadUserProfile()
                    .then(function () {
                        socketService.webSocketInit();

                        if ($location.url() === '/login') {
                            $location.url('/');
                        }
                    })
                    .catch(function () {
                        $location.url('/login');
                    })
            }
        }
    }

})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .service('widgetDesc', widgetDesc);

    widgetDesc.$inject = ['intercomService'];

    function widgetDesc(intercomService) {

        /**
         * data:
         * @string param : desc - описание виджета для отображения
         * @string param : title - название виджета
         */
        intercomService.on('widget: show-description',function(data){
            console.log('Service',data);
            //TODO развертывание окна с описанием виджета
        });

    }

})();




(function () {
    'use strict';

    angular
        .module('uspy')
        .service('userProfileService', userProfileService);

    userProfileService.$inject = ['$http', '$q', 'config'];

    function userProfileService($http, $q, config) {

        let userProfile = undefined; //Профиль пользователя
        let loaderPromise = null; //Обеспечение синглтона

        this.resetUserProfile = resetUserProfile; //Обнуление данных о вошедшем пользователе
        this.loadUserProfile = loadUserProfile; //Загрузка профиля пользователя
        this.reloadUserProfile = reloadUserProfile; //Перезапрос данных пользоватедя
        this.getUserProfile = getUserProfile; //Получение данных пользователя

        /**
         * Загрузка профиля пользователя
         * @returns {angular.IPromise<UserProfile>}
         */
        function loadUserProfile() {
            let user = localStorage.getItem('user');

            if (!loaderPromise) {
                loaderPromise = $http.get(config.apiServer + '/users/' + user)
                    .then(loadUserProfileComplete)
                    .catch(loadUserProfileFailed);
            }

            return loaderPromise;

            function loadUserProfileComplete(response) {
                console.log('SERVICE : loadUserProfile : user login success :', response.data);

                userProfile = response.data.data;
                loaderPromise = $q.when(userProfile);
                return userProfile;
            }

            function loadUserProfileFailed(error) {
                loaderPromise = null;
                console.log('USER-SERVICE : loadUserProfile : user not found');
                return $q.reject(error);
            }
        }

        /**
         * Перезапрос данных пользоватедя
         * @returns {angular.IPromise<UserProfile>}
         */
        function reloadUserProfile() {
            loaderPromise = null;
            return loadUserProfile().then(function (userProfile) {
                return userProfile;
            });
        }

        /**
         * Получение данных пользователя
         * @returns {UserProfile}
         */
        function getUserProfile() {
            return userProfile;
        }

        /**
         * Обнуление данных о вошедшем пользователе
         */
        function resetUserProfile() {
            userProfile = undefined;
            loaderPromise = null;
        }
    }

})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .service('serverStatus', serverStatus);

    serverStatus.$inject = [];

    function serverStatus() {
        this.textStatus = textStatus; //Описание текущего статуса сервера и действия с ним

        /**
         * 0 - сервер не отвечает
         * 1 - соединение установлено
         * 2 - сохранение проекта
         * 3 - ожидание ответа от сервера
         * 4 - сервер выдал ошибку
         * 666 - критическая ошибка сервера. Нужно перезагрузить страницу
         */


        /**
         * Описание текущего статуса сервера и действия с ним
         * @param status - @text - статус работы с сервером
         * @returns {*} - @text - описание статуса
         */
        function textStatus(status) {
            switch (status) {
                case 1:
                    return 'Сервер работает.';
                    break;
                case 0:
                    return 'Соединение с сервером потеряно!';
                    break;
                case 2:
                    return 'Восстанавливаем подключение к серверу...';
                    break;

            }
        }


    }

})();


(function () {
    'use strict';

    angular
        .module('uspy')
        .service('intercomService', intercomService);

    intercomService.$inject = [];

    function intercomService() {
        /**
         * @type {{ emit: function, on: function, off: function }}
         */
        let intercom = Intercom.getInstance();
        
        this.emit = emit;
        this.on = on;
        this.off = off;

        ////////////////

        /**
         * Отправка сообщения в intercom
         * @param {string} event
         * @param {*} [data]
         */
        function emit(event, data) {
            intercom.emit(event, data);
        }

        /**
         * Подписка на события intercom
         * @param {string} event
         * @param {function} callback
         */
        function on(event, callback) {
            intercom.on(event, callback);
        }

        /**
         * Отписка от события event функции callback
         * @param {string} event
         * @param {function} callback
         */
        function off(event, callback) {
            intercom.off(event, callback);
        }
    }

})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .service('authenticationService', authenticationService);

    authenticationService.$inject = ['$http', 'intercomService','config'];

    /**
     * 
     * @param $http
     * @param {intercomService} intercomService
     */
    function authenticationService($http, intercomService,config) {
        this.logout = logout;
        this.login = login;
        this.reg = reg;

        ////////////////

        function logout() {
            return $http
                .get('/api/logout')
                .then(function () {
                    intercomService.emit('authentication.logout');
                });
        }

        function login(email, password) {
            let data =  {
                email: email,
                password: password
            };
            return $http
                .post(config.apiServer + '/login', data)
                .then(function (response) {
                    intercomService.emit('authentication.login');
                });
        }

        function reg(email, password){
            let data = {
                login: email,
                password: password
            };
            $http.post(config.apiServer + '/reg', data)
        }
    }

})();


(function () {
    'use strict';

    angular
        .module('uspy')
        .controller('loginController', loginController);

    loginController.$inject = ['$timeout','$scope','authenticationService'];

    function loginController($timeout,$scope,authenticationService) {
        let vm = this;
        /**
         * 1 - чувак входил и мы знаем его почту
         * 2 - чувак впервые входит
         * 3 - ввод пароля
         * 4 - страница входа
         */
        vm.page = 1;
        vm.debounce = 1000; //задержка перед изменением модели

        vm.login = login;
        vm.registration = registration;
        vm.switchPage = switchPage;
        vm.goToFirst = goToFirst;
        vm.activePage = activePage;

        activate();
        ///////////////////
        function activate() {

        }

        /********************************** ВХОД НА САЙТ ********************************/

        function login(){
            authenticationService.login(vm.email, vm.password);
        }

        /**
         * Смена страницы окна
         * @param page
         */
        function switchPage(page) {
            $timeout(function(){
                vm.page = page;
            })
        }

        /**
         * Переход на страниц ввода логина и пароля
         */
        function goToFirst() {
            $timeout(function(){
                vm.page = 2;
            })
        }

        /**
         * Добавление класса к кнопкам
         * @param button
         * @returns {boolean}
         */
        function activePage(button){
            if (button === 'enter') {
                if (vm.page === 1 || vm.page === 2 || vm.page === 3) {
                    return true;
                }
            } else if (button === 'reg') {
                if (vm.page === 4 || vm.page === 5 || vm.page === 6) {
                    return true;
                }
            }
        }

        /********************************** РЕГИСТРАЦИЯ ********************************/

        function registration(){
            authenticationService.reg(vm.regLogin, vm.regPass);
        }

    }
})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('loginConfig', {

        })

})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .controller('indexController', indexController);

    indexController.$inject = [];

    function indexController() {
        let vm = this;

        activate();
        ///////////////////
        function activate() {

        }

    }
})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('indexConfig', {

        })

})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .controller('headerController', headerController);

    headerController.$inject = ['intercomService','headerConfig'];

    function headerController(intercomService,headerConfig) {
        let vm = this;
        vm.config = headerConfig;

        activate();
        ///////////////////
        function activate() {
            setCanvasSize();
        }

        /**
         * Создание пользовательского холста
         * @param x - ширина хослта
         * @param y - высота холста
         * header-canvas-create
         */
        function setCanvasSize() {
            intercomService.on('canvas-resize-from-create',function(data){
                vm.config.defaultCanvasWidth = data.width;
                vm.config.defaultCanvasHeight = data.height;
            });
        }
    }
})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('headerConfig', {
            defaultCanvasWidth: 800,
            defaultCanvasHeight: 300
        })

})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .controller('constructorController', constructorController);

    constructorController.$inject = ['$rootScope', '$scope', 'intercomService', 'widgetDesc', 'fabricFactory', 'fabricConstants', 'canvasConfig'];

    function constructorController($rootScope, $scope, intercomService, widgetDesc, fabricFactory, fabricConstants, canvasConfig) {
        let vm = this;
        vm.canvasWidth = 795; //дефолтная ширина холста
        vm.canvasHeight = 200; //дефолтнная высота холста
        vm.canvasStyle = 'width:' + vm.canvasWidth + 'px; height:' + vm.canvasHeight + 'px';
        vm.dictionary = {
            textVk: '<i class="fa fa-vk"></i><span> Вконтакте</span>',
            textYt: '<i class="fa fa-youtube"></i><span> Youtube</span>',
            textTw: '<i class="fa fa-twitch"></i><span> Twitch</span>',
            textOther: '<i class="fa fa-puzzle-piece"></i><span> Основные</span>'
        };
        vm.fabricConstants = fabricConstants;
        vm.fabric = {};

        $rootScope.openWidgetDescription = openWidgetDescription;
        vm.logThis = logThis;
        vm.openWidgetDescription = openWidgetDescription;
        vm.intercomActivate = intercomActivate;


        activate();

        ///////////////////
        function activate() {
            $scope.$on("drag-ready", function (e, d) {
                console.log("Drag ready", e, d);
            });
            $scope.$on('canvas:created', canvasInit);
        }

        /**
         * DEBUG ONLY
         * Вывод информации о событиях Drag & Drop объектов
         * @param message - событие
         * @param draggable - перетаскиваемый объект
         * @param droppable - то, что только что закинули на холст
         * @returns {*}
         */
        function logThis(message, draggable, droppable) {
            return console.log(message, {
                'draggable': draggable,
                'droppable': droppable
            });
        }

        /**
         * Отслеживание событий из Intercom
         */
        function intercomActivate() {

            intercomService.emit('constructor-on');

            intercomService.on('widget: add: text', function () {
                vm.fabric.addText();
            });

        }

        /**
         * Открытие модального окна с описанием виджета
         * @param widget
         */
        function openWidgetDescription(widget) {
            console.log('открываю модалку', widget);
            /*switch (widget) {
                case 'some-text':
                    break;
                default:
                    break;
            }*/
        }

        /**
         * Инициализация канваса
         */
        function canvasInit() {
            vm.fabric = new fabricFactory({
                JSONExportProperties: vm.fabricConstants.JSONExportProperties,
                textDefaults: vm.fabricConstants.textDefaults,
                shapeDefaults: vm.fabricConstants.shapeDefaults,
                json: null
            });
            setCanvasSize(canvasConfig.sizeCollection[0].width, canvasConfig.sizeCollection[0].height);
        }

        /**
         * Изменени размера рабочей области
         * @param width - ширина
         * @param height - высота
         */
        function setCanvasSize(width, height) {
            vm.fabric.setCanvasSize(width, height);
            /**
             * Отображение данных в хедере
             */
            intercomService.emit('canvas-resize-from-create', {
                width: width,
                height: height
            });
        }


    }
})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .controller('footerController', footerController);

    footerController.$inject = ['config','$scope','serverStatus','footerConfig','socketService','intercomService','$timeout'];

    function footerController(config,$scope,serverStatus,footerConfig,socketService,intercomService,$timeout) {
        let vm = this;
        vm.config = config;
        vm.apiActive = 0; //Начальная установка на соединение с сервером
        vm.serverStatusText = 'Ждем ответа от сервера...';

        activate();
        ///////////////////
        function activate() {
            pingServer(); //Опрос сервера на активность

            $scope.$on('PING',function(data){
                $timeout(function(){
                    vm.apiActive = 1;
                    vm.serverStatusText = serverStatus.textStatus(vm.apiActive);
                })

            });

            intercomService.on('WS_CONNECTION_LOSS',function(){
                $timeout(function(){
                    vm.apiActive = 0;
                    vm.serverStatusText = serverStatus.textStatus(vm.apiActive);
                })
            });

            intercomService.on('WS_RECONNECT',function(){
                $timeout(function(){
                    vm.apiActive = 2;
                    vm.serverStatusText = serverStatus.textStatus(vm.apiActive);
                })
            });


        }

        /**
         * Опрос сервера на активность
         */
        function pingServer() {

            /**
             * Запрос на активность сервера
             */
            function testServer(){
                socketService.sendMessage({
                    message_type: 'PING'
                });
            }

            if (socketService.isOpened()) {
                testServer(); //Запрос на активность сервера
            }

            setInterval(function(){
                if (socketService.isOpened()) {
                    testServer(); //Запрос на активность сервера
                }
            },footerConfig.pingTimeOut)
        }


    }
})();
(function () {
    'use strict';

    angular
        .module('uspy')
        .constant('footerConfig', {
            pingTimeOut: 1000, //Время опроса сервера на состояние
        })

})();